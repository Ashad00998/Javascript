print("Задание 4")
import random


n = int(input("Введите количество элементов массива: "))


array_1d = [random.randint(-100, 100) for _ in range(n)]
print("Сгенерированный массив:", array_1d)

count_divisible_by_3 = sum(1 for x in array_1d if x % 3 == 0)
even_numbers = [x for x in array_1d if x % 2 == 0]

if even_numbers:
    average_even = sum(even_numbers) / len(even_numbers)
else:
    average_even = 0

print("Количество чисел, делящихся на 3:", count_divisible_by_3)
print("Среднее арифметическое четных чисел:", average_even)