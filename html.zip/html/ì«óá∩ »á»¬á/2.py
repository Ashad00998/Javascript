import random 
 
rows = int(input("Введите количество строк: ")) 
cols = int(input("Введите количество столбцов: ")) 
 
array = [] 
 
for i in range(rows): 
    row = [] 
    for j in range(cols): 
        row.append(random.randint(-20, 20)) 
    array.append(row) 
 
print("Сгенерированный массив:") 
for row in array: 
    print(row) 
 
min_element = array[0][0] 
for row in array: 
    for element in row: 
        if element < min_element: 
            min_element = element 
print("Минимальный элемент:", min_element) 
 
print("Вторая строка:", array[1]) 
 
first_column = [] 
for row in array: 
    first_column.append(row[0]) 
print("Первый столбец:", first_column)