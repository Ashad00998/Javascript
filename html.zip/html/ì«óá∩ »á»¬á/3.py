print("Задание 3")
n = int(input("Введите количество элементов массива: "))


array_1d = []
for i in range(n):
    element = int(input(f"Введите элемент {i + 1}: "))
    array_1d.append(element)

has_consecutive_zeros = any(array_1d[i] == 0 and array_1d[i + 1] == 0 for i in range(len(array_1d) - 1))
if has_consecutive_zeros:
    print("В массиве есть два подряд идущих нуля.")
else:
    print("В массиве нет двух подряд идущих нулей.")