const { price, translatedRange } = require("./app");

export let result = `${price} Р в ${translatedRange}`;
