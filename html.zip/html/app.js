// Пузырьковая сортировка
function bubbleSort(arr) {
    let n = arr.length;
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n - i - 1; j++) {
           
            if (arr[j] > arr[j + 1]) {
                [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
            }
        }
    }
    return arr;
}

// Сортировка выбором
function selectionSort(arr) {
    let n = arr.length;
    for (let i = 0; i < n; i++) {
        let minIndex = i; 
        for (let j = i + 1; j < n; j++) {
            
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        
        [arr[i], arr[minIndex]] = [arr[minIndex], arr[i]];
    }
    return arr;
}

// Сортировка слиянием
function mergeSort(arr) {
    if (arr.length <= 1) {
        return arr; 
    }
    const mid = Math.floor(arr.length / 2); 
    const left = mergeSort(arr.slice(0, mid)); 
    const right = mergeSort(arr.slice(mid)); 
    
    return merge(left, right); 
}


function merge(left, right) {
    let result = [];
    let i = 0, j = 0;

    
    while (i < left.length && j < right.length) {
        if (left[i] < right[j]) {
            result.push(left[i]);
            i++;
        } else {
            result.push(right[j]);
            j++;
        }
    }
    
    return result.concat(left.slice(i)).concat(right.slice(j));
}

// Сортировка подсчетом
function countingSort(arr) {
    const maxVal = Math.max(...arr); 
    const count = new Array(maxVal + 1).fill(0); 
    const output = new Array(arr.length); 

   
    for (let num of arr) {
        count[num]++;
    }

  
    for (let i = 1; i <= maxVal; i++) {
        count[i] += count[i - 1];
    }

  
    for (let i = arr.length - 1; i >= 0; i--) {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }

    return output;
}

// Быстрая сортировка
function quickSort(arr) {
    if (arr.length <= 1) {
        return arr; 
    }
    const pivot = arr[Math.floor(arr.length / 2)]; 
    const left = arr.filter(x => x < pivot); 
    const middle = arr.filter(x => x === pivot); 
    const right = arr.filter(x => x > pivot); 
    return [...quickSort(left), ...middle, ...quickSort(right)]; 
}


function testSortingAlgorithms() {
    const sizes = [10, 100, 1000, 10000]; 
    const results = {};
}

    sizes.forEach(size => {
        const arr = Array.from({ length: size }, () => Math.floor(Math.random() * 10000));
        results[size] = {};
    })

        