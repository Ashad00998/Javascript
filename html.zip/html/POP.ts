// Абстрактный класс Publisher
abstract class Publisher {
    constructor(
        private _title: string, // Это название книги
        private _author: string, // Это название автора
        private _pubYear: number, // Это когда создали или сделали книгу
        private _copies: number // Это количество копий
    ) {}

    // Методы для получения значений полей
    get title(): string { // get получает значение полей
        return this._title; 
    }

    get author(): string {
        return this._author;
    }

    get pubYear(): number {
        return this._pubYear;
    }

    get copies(): number {
        return this._copies;
    }

    // Методы для изменения значений полей
    set title(value: string) {  // set позволяет как я помню изменить значение полей
        this._title = value;
    }

    set author(value: string) {
        this._author = value;
    }

    set pubYear(value: number) {
        this._pubYear = value;
    }

    set copies(value: number) {
        this._copies = value;
    }
}

// Интерфейс Reception
interface Reception {
    delivery(): void; // Метод для выдачи издания.
    receive(): void; // Метод для возврата издания.
}

// Класс Book
class Book extends Publisher implements Reception {
    constructor(
        title: string,
        author: string,
        pubYear: number,
        copies: number,
        private _pages: number   // Количество страниц в книге.
    ) {
        super(title, author, pubYear, copies);
    }

    get pages(): number {
        return this._pages;
    }

    set pages(value: number) {
        this._pages = value;
    }

    delivery(): void { // Уменьшает количество штук книг на 1, если они есть.   доставка
        if (this.copies > 0) {
            this.copies--;
            console.log(`Книга "${this.title}" выдана. Осталось экземпляров: ${this.copies}`);
        } else {
            console.log(`Книга "${this.title}" отсутствует в наличии.`);
        }
    }

    receive(): void { // Увеличивает количество экземпляров книги на 1. Получать
        this.copies++;
        console.log(`Книга "${this.title}" возвращена. Теперь экземпляров: ${this.copies}`);
    }
}

// Класс Magazine
class Magazine extends Publisher implements Reception {  // Этот класс также наследует Publisher и реализует интерфейс Reception
    constructor(
        title: string,
        author: string,
        pubYear: number,
        copies: number,
        private _issue: number
    ) {
        super(title, author, pubYear, copies);
    }

    get issue(): number {
        return this._issue; // вопрос . Номер журнала
    }

    set issue(value: number) {
        this._issue = value;
    }

    delivery(): void {
        if (this.copies > 0) {
            this.copies--;
            console.log(`Журнал "${this.title}" выдан. Осталось экземпляров: ${this.copies}`);
        } else {
            console.log(`Журнал "${this.title}" отсутствует в наличии.`);
        }
    }

    receive(): void {
        this.copies++;
        console.log(`Журнал "${this.title}" возвращен. Теперь экземпляров: ${this.copies}`);
    }
}

// Класс Reader
class Reader {   // Этот класс представляет читателя.
    private _items: Publisher[] = [];

    constructor(
        private _firstName: string,
        private _lastName: string,
        private _maxItems: number = 3
    ) {}

    get firstName(): string {   // _firstName: Имя читателя.
        return this._firstName;
    }

    get lastName(): string { // _lastName: Фамилия читателя.
        return this._lastName;
    }

    get items(): Publisher[] { // _items: Список изданий, которые находятся у читателя.
        return this._items;
    }

    set firstName(value: string) { 
        this._firstName = value;
    }

    set lastName(value: string) {
        this._lastName = value;
    }

    // Метод для выдачи издания
    deliveryItem(item: Publisher & Reception): void {  // Выдает издание читателю, если есть свободные экземпляры и у читателя нет максимального количества изданий.
        if (this._items.length >= this._maxItems) {  // _maxItems: Максимальное количество изданий, которые может взять читатель
            console.log(`У читателя ${this.firstName} ${this.lastName} уже максимальное количество изданий.`);
            return;
        }

        if (this._items.includes(item)) {
            console.log(`У читателя ${this.firstName} ${this.lastName} уже есть издание "${item.title}".`);
            return;
        }

        if (item.copies > 0) {
            this._items.push(item);
            (item as Reception).delivery();
        } else {
            console.log(`Издание "${item.title}" отсутствует в наличии.`);
        }
    }

    // Метод для возврата издания
    receiveItem(item: Publisher & Reception): void { // receiveItem(item): Возвращает издание в библиотеку.
        const index = this._items.indexOf(item);
        if (index !== -1) {
            this._items.splice(index, 1);
            (item as Reception).receive();
        } else {
            console.log(`У читателя ${this.firstName} ${this.lastName} нет издания "${item.title}".`);
        }
    }
}

// Класс Library
class Library {
    private _items: Publisher[] = []; // _items: Список всех изданий в библиотеке.

    addItem(item: Publisher): void { // addItem(item): Добавляет издание в библиотеку
        this._items.push(item);
        console.log(`Издание "${item.title}" добавлено в библиотеку.`);
    }

    removeItem(item: Publisher): void { // removeItem(item): Удаляет издание из библиотеки.
        const index = this._items.indexOf(item);
        if (index !== -1) {
            this._items.splice(index, 1);
            console.log(`Издание "${item.title}" удалено из библиотеки.`);
        } else {
            console.log(`Издание "${item.title}" отсутствует в библиотеке.`);
        }
    }

    get items(): Publisher[] {
        return this._items;
    }
}

// Тестирование
const book1 = new Book("Война и мир", "Лев Толстой", 1869, 5, 1225);
const magazine1 = new Magazine("National Geographic", "Various", 2023, 10, 123);

const reader1 = new Reader("Иван", "Иванов");

const library = new Library();
library.addItem(book1);
library.addItem(magazine1);

reader1.deliveryItem(book1);
reader1.deliveryItem(magazine1);
reader1.deliveryItem(book1); // Попытка взять книгу, которая уже на руках

reader1.receiveItem(book1);
reader1.receiveItem(magazine1);

library.removeItem(book1);
library.removeItem(magazine1);